#ifndef INST_SHIFT_H
#define INST_SHIFT_H
/* 命令 */

#include "isa.h"

int isa_shift(Cpub *cpub, const Instruction *inst);

#endif /* INST_SHIFT_H */
