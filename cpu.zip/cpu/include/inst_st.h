#ifndef INST_ST_H
#define INST_ST_H
/* 命令 */

#include "isa.h"
#include "mem.h"

int isa_st(Cpub *cpub, const Instruction *inst);

#endif /* INST_ST_H */
