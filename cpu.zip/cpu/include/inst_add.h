#ifndef INST_ADD_H
#define INST_ADD_H
/* 命令 */

#include "isa.h"

int isa_add(Cpub *cpub, const Instruction *inst);

#endif /* INST_ADD_H */
