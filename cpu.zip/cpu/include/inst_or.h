#ifndef INST_OR_H
#define INST_OR_H
/* 命令 */

#include "isa.h"

int isa_or(Cpub *cpub, const Instruction *inst);

#endif /* INST_OR_H */
