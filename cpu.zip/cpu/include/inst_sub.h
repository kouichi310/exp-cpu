#ifndef INST_SUB_H
#define INST_SUB_H
/* 命令 */

#include "isa.h"

int isa_sub(Cpub *cpub, const Instruction *inst);

#endif /* INST_SUB_H */
