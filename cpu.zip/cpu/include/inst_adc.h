#ifndef INST_ADC_H
#define INST_ADC_H
/* 命令 */

#include "isa.h"

int isa_adc(Cpub *cpub, const Instruction *inst);

#endif /* INST_ADC_H */
