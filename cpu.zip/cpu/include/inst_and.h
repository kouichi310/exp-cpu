#ifndef INST_AND_H
#define INST_AND_H
/* 命令 */

#include "isa.h"

int isa_and(Cpub *cpub, const Instruction *inst);

#endif /* INST_AND_H */
