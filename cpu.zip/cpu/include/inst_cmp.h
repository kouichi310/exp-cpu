#ifndef INST_CMP_H
#define INST_CMP_H
/* 命令 */

#include "isa.h"

int isa_cmp(Cpub *cpub, const Instruction *inst);

#endif /* INST_CMP_H */
