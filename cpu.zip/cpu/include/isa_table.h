#ifndef ISA_TABLE_H
#define ISA_TABLE_H
/* テーブル宣言 */

#include "isa.h"

extern ExecFunc isa_exec_table[256];

#endif /* ISA_TABLE_H */
