#ifndef INST_LD_H
#define INST_LD_H
/* 命令 */
/* LD命令 */

#include "isa.h"

int isa_ld(Cpub *cpub, const Instruction *inst);

#endif /* INST_LD_H */
