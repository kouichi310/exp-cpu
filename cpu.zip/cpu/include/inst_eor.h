#ifndef INST_EOR_H
#define INST_EOR_H
/* 命令 */

#include "isa.h"

int isa_eor(Cpub *cpub, const Instruction *inst);

#endif /* INST_EOR_H */
