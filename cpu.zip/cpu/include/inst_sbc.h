#ifndef INST_SBC_H
#define INST_SBC_H
/* 命令 */

#include "isa.h"

int isa_sbc(Cpub *cpub, const Instruction *inst);

#endif /* INST_SBC_H */
