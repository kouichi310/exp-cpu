#ifndef INST_BNZ_H
#define INST_BNZ_H
/* 命令 */

#include "isa.h"

int isa_branch(Cpub *cpub, const Instruction *inst);

#endif /* INST_BNZ_H */
