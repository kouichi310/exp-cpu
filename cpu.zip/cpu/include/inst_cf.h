#ifndef INST_CF_H
#define INST_CF_H
/* 命令 */

#include "isa.h"

int isa_cf(Cpub *cpub, const Instruction *inst);

#endif /* INST_CF_H */
